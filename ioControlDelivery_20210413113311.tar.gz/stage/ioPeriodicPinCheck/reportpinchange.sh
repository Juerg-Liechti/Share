#!/bin/sh

# reportpinchange.sh
#   check if pins changed. if so, report it via e-mail.

subject_line="[$(hostname)] Pin changed"

# get a temp file. Note busybox need at least 6 'X' usually 3 is enough...
pinreport_tmp_file=`mktemp -t tmp_pinreport.XXXXXX`
./testpinchange.sh ${pinreport_tmp_file}
if [ $? -eq 1 ]; then
    echo "We have to report something!"
    ( ./emailreport.sh "${subject_line}" ${pinreport_tmp_file} )
fi

