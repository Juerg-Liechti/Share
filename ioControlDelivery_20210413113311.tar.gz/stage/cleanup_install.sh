#!/bin/bash

echo "--- Clean up install files ---"
read -p "Do you want clean up the installation files? [y,N] " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Remove delivery archive(s)"
    rm -f ioControlDelivery_*.tar.gz
    echo "Remove stage directory"
    rm -rf stage
fi
