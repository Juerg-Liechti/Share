"use strict";

// Get the content of 'agnes_links.html' and write it to the jumbotron 
// Idea: agnes_links.htlm can be edited by admin of the station.
function loadAgnesLinks(file)
{
    var linksFile = "agnes_links.html";
    var rawFile = new XMLHttpRequest();
    rawFile.open("GET", linksFile, true);
    rawFile.onreadystatechange = function ()
    {
        if(rawFile.readyState === 4)
        {
            if(rawFile.status === 200 || rawFile.status == 0)
            {
                document.getElementById("agnesLinks").innerHTML = rawFile.responseText;
            }
        }
    }
    rawFile.send(null);
}


// flag needed handle update of desired outputs
var desiredOutputsValid = false;
// call this to force an update next time new output pins are received
function invalidateDesiredOutputs() {
    desiredOutputsValid = false;
}

//--- interval timer ---
var intervalTimer = null;
var intervalMilliseconds = 0;

function startTimer() {
    if (intervalTimer != null) {
        clearInterval(intervalTimer);
    }
    intervalTimer = setInterval(requestPinStatus, intervalMilliseconds);
}

function stopTimer() {
    clearInterval(intervalTimer);
    intervalTimer = null;
}

function setReadInterval(intervalSec) {
    document.getElementById("readIntervalLbl").innerHTML = intervalSec + " sec";
    intervalMilliseconds = intervalSec * 1000.0;
    if (document.getElementById("readContinousChkbx").checked) {
        startTimer();
    }
}

function setReadContinous(enableContinousRead) {
    if (enableContinousRead) {
        startTimer();
    } else {
        stopTimer();
    }
}

function initReadInterval(intervalSec, intervalSecMin = 0.5, intervalSecMax = 120.0, intervalSecStep = 0.1) {
    var slider = document.getElementById("readIntervalSlider");
    slider.min = intervalSecMin;
    slider.max = intervalSecMax;
    slider.step = intervalSecStep;
    slider.value = intervalSec;
    setReadInterval(intervalSec);
}


function setDesiredOutput(pinNumber, value) {
    // when write immadiately is active, send the desired outputs
    if (document.getElementById("writeImmediateChkbx").checked == true) {
        sendOutputPins();
    }
}

function setInputState(inputState) {
    // inputState: 12bit inputstate stored as JS number
    var k;
    for (k = 1; k <= 12; k++) {
        var el = document.getElementById("in" + k + "Current");
        if (inputState & 0x00000001) {
            el.innerHTML = "ON";
            el.classList.replace("bg-dark", "bg-primary");
        }
        else {
            el.innerHTML = "OFF";
            el.classList.replace("bg-primary", "bg-dark");
        }
        inputState = inputState >> 1;
    }
}

function setOutputState(outputState) {
    // outputState: 8bit outputState stored as JS number
    var k;
    for (k = 1; k <= 8; k++) {
        var el = document.getElementById("out" + k + "Current");
        if (outputState & 0x00000001) {
            el.innerHTML = "ON";
            el.classList.replace("bg-dark", "bg-primary");
        }
        else {
            el.innerHTML = "OFF";
            el.classList.replace("bg-primary", "bg-dark");
        }
        outputState = outputState >> 1;
    }
}

function updateDesiredOutputState() {
    // resetDesiredState: resets the desired output state to match the acutal output
    var k;
    for (k = 1; k <= 8; k++) {
        var el = document.getElementById("out" + k + "Current");
        var elChk = document.getElementById("out" + k + "Chkbx");
        if (el.innerHTML == "ON") {
            elChk.checked = true;
        } else {
            elChk.checked = false;
        }
    }
}

function getDesiredOutputState() {
    // returns the current desired outputState of 8bits stored as JS number
    var k;
    var desiredOutputState = 0x00000000;
    for (k = 8; k > 0; k--) {
        desiredOutputState = desiredOutputState << 1;
        var elChk = document.getElementById("out" + k + "Chkbx");
        if (elChk.checked == true) {
            desiredOutputState = desiredOutputState | 0x00000001;
        }
    }
    return desiredOutputState;
}

function setInputPinAlias(pinAlias) {
    // pinAlias: array with 12 strings containing the aliases for the input pins
    var k;
    for (k = 1; k <= 12 && k <= pinAlias.length; k++) {
        var el = document.getElementById("in" + k + "AliasLabel").innerHTML = pinAlias[k - 1];
    }
}

function setOutputPinAlias(pinAlias) {
    // pinAlias: array with 8 strings containing the aliases for the output pins
    var k;
    for (k = 1; k <= 8 && k <= pinAlias.length; k++) {
        var el = document.getElementById("out" + k + "AliasLabel").innerHTML = pinAlias[k - 1];
    }
}

function setInputPinFunction(pinFunction) {
    // pinFunction: array with 12 strings containing the function description for the input pins
    var k;
    for (k = 1; k <= 12 && k <= pinFunction.length; k++) {
        var el = document.getElementById("in" + k + "FunctionLabel").innerHTML = pinFunction[k - 1];
    }
}

function setOutputPinFunction(pinFunction) {
    // pinFunction: array with 8 strings containing the function description for the output pins
    var k;
    for (k = 1; k <= 8 && k <= pinFunction.length; k++) {
        var el = document.getElementById("out" + k + "FunctionLabel").innerHTML = pinFunction[k - 1];
    }
}

function handlePinStatusResponse() {
    if (this.readyState == 4 && this.status == 200) {
        setInputState(this.response.input_pins);
        setOutputState(this.response.output_pins);
        if (desiredOutputsValid == false) {
            updateDesiredOutputState();
            desiredOutputsValid = true;
        }
        setServerConnectionAlertOk();
    } else if (this.status >= 400) {
        setServerConnectionAlertFail();
    }
}

function requestPinStatus() {
    var xhttp = new XMLHttpRequest();
    xhttp.responseType = 'json';
    xhttp.open("GET", "/iocall?pin_status", true);
    xhttp.timeout = 5000;
    xhttp.ontimeout = setServerConnectionAlertFail;
    xhttp.onreadystatechange = handlePinStatusResponse;
    xhttp.send();
}

function sendOutputPins() {
    var xhttp = new XMLHttpRequest();
    xhttp.responseType = 'json';
    xhttp.open("POST", "/iocall", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.timeout = 5000;
    xhttp.ontimeout = setServerConnectionAlertFail;
    xhttp.onreadystatechange = handlePinStatusResponse;
    xhttp.send(JSON.stringify({ output_pins: getDesiredOutputState() }));
}

// Update the top lead (header of the web page) so far just the version
function updateTopLead(versionInfo = { 'iocontrol_srv': '?' }) {
    var l = document.getElementById("topLead");
    l.innerHTML = "ioControl server version: " + versionInfo.iocontrol_srv;
}

// Get the response and update the top lead (header of the web page)
function handleVersionResponse() {
    if (this.readyState == 4 && this.status == 200) {
        updateTopLead(this.response);
        setServerConnectionAlertOk();
    } else if (this.status >= 400) {
        setServerConnectionAlertFail();
    }
}

// Request the version infomation from the io controller
function requestVersion() {
    var url = "/iocall?version";
    var xhttp = new XMLHttpRequest();
    xhttp.responseType = 'json';
    xhttp.open("GET", url, true);
    xhttp.timeout = 5000;
    xhttp.ontimeout = setServerConnectionAlertFail;
    xhttp.onreadystatechange = handleVersionResponse;
    xhttp.send();
}

function setServerConnectionAlertOk() {
    var al = document.getElementById("serverConnectionAlert");
    if (!al.classList.contains("alert-success")) {
        al.innerHTML = "Server connection okay";
        al.classList = "alert alert-success mt-3";
    }
}

function setServerConnectionAlertFail() {
    var al = document.getElementById("serverConnectionAlert");
    if (!al.classList.contains("alert-danger")) {
        al.innerHTML = "Server connection failed";
        al.classList = "alert alert-danger mt-3";
    }
}

function setServerConnectionAlertUnknwon() {
    var al = document.getElementById("serverConnectionAlert");
    if (!al.classList.contains("alert-warning")) {
        al.innerHTML = "No server connection yet";
        al.classList = "alert alert-warning mt-3";
    }
}
