#!/bin/sh

# emailreport.sh SUBJECT BODYFILE
#   Sends an e-mail with subject SUBJECT and the
#   content of BODYFILE as body.
#
# from/to need to be specified in emailreport.conf, e.g.:
#   from=agni.ness@yandex.com
#   to=t.brossi@mylab.ch,s.brossi@mylab.ch,sdbrossi@gmail.com
#   cc=
#   bcc=
#
# use ',' but no space to specify multiple addresses.
#

# Build config file
fbname=$(basename "$0" | cut -d. -f1)
config_file=${fbname}".conf"

# Get from, to, cc and bcc
msg_from=$(awk -F'=' '$1 == "from" {print $2}' $config_file)
msg_to=$(awk -F'=' '$1 == "to" {print $2}' $config_file)
msg_cc=$(awk -F'=' '$1 == "cc" {print $2}' $config_file)
msg_bcc=$(awk -F'=' '$1 == "bcc" {print $2}' $config_file)

msg_subject=$1
msg_bodyfile=$2
# get a temp file. Note busybox need at least 6 'X' usually 3 is enough...
msg_tmp_file=$(mktemp -t tmp_mail.XXXXXX)

# Create mail as file (note: the extra newline in front of the body)
printf "To: %s\nCc: %s\nBcc: %s\n" "${msg_to}" "${msg_cc}" "${msg_bcc}" >${msg_tmp_file}
printf "From: %s\nSubject: %s\n" "${msg_from}" "${msg_subject}" >>${msg_tmp_file}
printf "MIME-Version: 1.0\n" >>${msg_tmp_file}
printf "Content-Type: text/html\n" >>${msg_tmp_file}
printf "Content-Disposition: inline\n" >>${msg_tmp_file}
printf "\n" >>${msg_tmp_file}
printf "<html>\n" >>${msg_tmp_file}
printf "<body>\n" >>${msg_tmp_file}
printf "<pre style=\"font: monospace\">\n" >>${msg_tmp_file}

cat ${msg_bodyfile} >>${msg_tmp_file}

printf "</pre>\n" >>${msg_tmp_file}
printf "</body>\n" >>${msg_tmp_file}
printf "</html>\n" >>${msg_tmp_file}

# sendmail
# -t: should parse To,From,... from the file (and remove bcc before sending)
# -v: verbose (might be disabled once fully tested at swisstopo okay).
/usr/sbin/sendmail -v -t <${msg_tmp_file}

# DEBUG/TEST:
cp ${msg_tmp_file} "last_mail.txt"

rm -f ${msg_tmp_file}

exit 0
