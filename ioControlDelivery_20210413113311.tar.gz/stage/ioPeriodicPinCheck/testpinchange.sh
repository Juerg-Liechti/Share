#!/bin/sh

# testpinchange.sh [REPORTFILE]
#   Uses ioControl to check if any pins changed.
#   If so, return true and write pin status before and 
#   after to REPORTFILE.
#   If not, return false.
#   Without REPORTFILE its default 'report.txt' is used. 
#
#   If the previous state is unknown, ioControl configure
#   is called first to initialize the pins.
# 
# testpinchange.sh --clear removes the status 
#   files (if any) and exits.
#   Use this after boot up to start "fresh".
#

#--- Definitions: Change as needed ---

# The pins to be tested. Empty checks all.
pin_list='IN1 IN2 CHARGER_FAIL POWER_FAIL BAT_FAIL OUT1'

# The file to record the previous status
last_pin_status_file=".last_pin_status"
curr_pin_status_file=".curr_pin_status"

#--- Commands for iocontrol ---
iocontrol_config_cmd='ioControl configure'
if [ -z "${pin_list}" ]; then
    iocontrol_get_cmd="ioControl get"
else
    iocontrol_get_cmd="ioControl get ${pin_list}" 
fi

#--- check arguments ---
# if there's an argument check it for options
if [ ! -z "$1" ]; then
    # clear the status files (if any) and EXIT
    if [ "$1" = "--clear" ]; then
        rm -f ${last_pin_status_file} ${curr_pin_status_file}
        exit 0
    fi
fi

# use first argument as report file
if [ ! -z "$1" ]; then
    report_file=$1
else
    report_file='report.txt' 
fi

#=== MAIN PART ===
# Check if last_pin_status_file exists.
#
# Yes: 
#   Write current status to the file curr_pin_status_file.
#   Compare last_pin_status_file and curr_pin_status_file.
#   If there's a diff, write info about change to the report file.
#
# No:
#   Initialize the pins.
#   Write current status to the file last_pin_status_file.
#   exit

if [ -f "$last_pin_status_file" ]; then
    # echo "$last_pin_status_file exist"
    ( $iocontrol_get_cmd > $curr_pin_status_file )
    if cmp -s ${last_pin_status_file} ${curr_pin_status_file}; then
        # echo "The files are the same"
        # remove the current file so we could get the date of last...
        rm ${curr_pin_status_file}
        return_value=0
    else
        # echo "The files are different"
	# write REPORTFILE
	current_date=`date`
	printf "%s - Pins changed\n" "${current_date}" > ${report_file}
        printf "%-7s%s\n" "From:" "`cat ${last_pin_status_file}`" >> ${report_file} 
        printf "%-7s%s\n" "To:" "`cat ${curr_pin_status_file}`" >> ${report_file}
	# Update status files
        mv ${curr_pin_status_file} ${last_pin_status_file}
        return_value=1
    fi
else 
    # echo "$last_pin_status_file does not exist."
    ( $iocontrol_config_cmd )
    ( $iocontrol_get_cmd > $last_pin_status_file )
    return_value=0
fi

exit $return_value


