#!/bin/bash

# Installs and configures AGNES ioControl on the target
# This should usually be part of the delivery archive

# ---- FUNCTIONS -----

# add or replace a config value in a key=value style config file
# Usage:
# add_or_replace_config_value FILE KEY NEW_VALUE [PRINT]
#   if PRINT is true, "KEY set to NEW_VALUE" is displayed
add_or_replace_config_value() {
    # check if the key exists
    if grep -q "^#\{0,1\}$2\s*=.*" "$1"; then
        # the key exists, update it
        sed -i "s/^#\{0,1\}$2\s*=.*/$2=$3/g" $1
    else
        # the key doen't exists, append it
        echo $2=$3 >>$1
    fi
    if [[ $4 == true ]]; then
        echo "$2 set to $3"
    fi
}

# Add entry to the crontab, with no duplication:
# Usage:
# add_cron_job CMD SCHEDULE [PRINT]
add_cron_job() {
    cronjob="$2 $1"
    (
        crontab -l | grep -v -F "$1"
        echo "$cronjob"
    ) | crontab -
    if [[ $3 == true ]]; then
        echo "Added cron job: $cronjob"
    fi
}

# Remove entry from the crontab whatever its current schedule:
# Usage:
# remove_cron_job CMD
#
# Btw: to remove all cron jobs: crontab -r
remove_cron_job() {
    (crontab -l | grep -v -F "$1") | crontab -
}


# Print the normal system users
# source: https://www.cyberciti.biz/faq/linux-list-users-command/
print_normal_system_users() {
    ## get mini UID limit ##
    l=$(grep "^UID_MIN" /etc/login.defs)

    ## get max UID limit ##
    l1=$(grep "^UID_MAX" /etc/login.defs)

    ## use awk to print if UID >= $MIN and UID <= $MAX   ##
    awk -F':' -v "min=${l##UID_MIN}" -v "max=${l1##UID_MAX}" '{ if ( $3 >= min && $3 <= max ) print $1" ("$0")"}' /etc/passwd
}


# ---- MAIN -----
echo "--- Installation and configuration of AGNES ioControl ---"

# Make sure we are su
if (($EUID != 0)); then
    echo "Please run as root"
    exit
fi

# Set root password
# to remove it: passwd -d root
root_user_status=$(passwd --status root)
# echo $root_user_status
if [[ $root_user_status == "root NP"* ]]; then
    echo "Root user password is not set!"
    read -p "Do you want to set the root password now? [y,N] " -n 1 -r
    echo # (optional) move to a new line
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        passwd
        echo "Warning: Please don't forget it!"
    fi
fi

# Add user
echo "Current users:"
print_normal_system_users
echo
read -p "Do you want to create a new user? [y,N] " -n 1 -r
echo # (optional) move to a new line
if [[ $REPLY =~ ^[Yy]$ ]]; then
    read -p "username: " username
    user_exists=$(
        id -u ${username} >/dev/null 2>&1
        echo $?
    )

    if [ $user_exists == 0 ]; then
        echo "${username} already exists! Not changing anything."
        if [[ $username == "root" ]]; then
            echo "(Are you sure YOU should be running this installation?"
            echo "CTRL+C gets you out of here...)"
        else
            echo "If you want delete and recreate the user, abort with CTRL+C and"
            echo "deluser ${username}"
            echo "rm -rf /home/${user}"
        fi
    else
        useradd ${username}
        passwd ${username}
    fi
fi

# Hostname / 4 character station ID  configuration
hname=$(hostname -s)
echo "Current hostname is: ${hname}"
if [ ${#hname} -ge 4 ]; then
    hname_4c=${hname: -4}
    echo "Four character ID (last 4 characters of hostname) is: ${hname_4c}"
else
    echo "No vaild four character ID can be derived from hostname!"
    hname_4c="NULL";
    echo "(Using default: ${hname_4c})"
fi
read -p "Do you want to set four character ID (and hostname)? [y,N] " -n 1 -r
echo # (optional) move to a new line
if [[ $REPLY =~ ^[Yy]$ ]]; then
    ok=0
    while [ $ok = 0 ]
    do
        read -e -p "Enter four character ID: " -i "${hname_4c}" -r hname_4c
        if [ ${#hname_4c} -ne 4 ]; then
            echo "Please enter 4 characters!"
        else
            ok=1
        fi
    done
    hname="control${hname_4c}"
    echo "New default hostname: ${hname}"
    read -p "Do you want to modify this hostname? [y,N] " -n 1 -r
    echo # (optional) move to a new line
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        read -e -p "Enter new hostname: " -i "$hname" -r hname
    fi
    echo "Setting hostname to ${hname}"
    hostname $hname
    echo "$hname" > /etc/hostname
fi

# Network config
read -p "Do you want to restore the default network configuration? [y,N] " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then

    # Interfaces (eth0, eth1)
    cp ./config/10-eth0.network /etc/systemd/network/10-eth0.network
    cp ./config/10-eth1.network /etc/systemd/network/10-eth1.network

    # Add symlink for DNS resolver (note: it gets written by the dhcp client):
    ln -sf /run/systemd/resolve/resolv.conf /etc/resolv.conf

    # open vi eth0 / eth1
    echo "You may now edit the configs for eth0 and eth1 using vi."
    echo "(<i> insert/start writing, <ESC>:wq write&exit, <ESC>:q! discard&exit)"
    read -p "Do you want to edit eth0? [y,N] " -n 1 -r
    echo # (optional) move to a new line
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        vi /etc/systemd/network/10-eth0.network
    fi
    echo "You may now edit the config for eth1 using vi."
    read -p "Do you want to edit eth1? [y,N] " -n 1 -r
    echo # (optional) move to a new line
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        vi /etc/systemd/network/10-eth1.network
    fi

    # Restart daemon to load new config: Don't do it here in case we are
    # connected via network. We ask at the very end.
    # systemctl restart systemd-networkd
    NETWORK_CONFIG_CHANGED=true
fi

read -p "Do you want restore the default NTP (chrony) configuration? [y,N] " -n 1 -r
echo # (optional) move to a new line
if [[ $REPLY =~ ^[Yy]$ ]]; then
    # Copy the config file and the keys (currently empty and not used)
    cp ./config/chrony.conf /etc/chrony.conf
    cp ./config/chrony.keys /etc/chrony.keys

    # Enable and restart
    systemctl enable chronyd
    systemctl restart chronyd

    # To check sources (DNS needs to be working; check e.g. ping www.sbb.ch):
    # chronyc sources -v
    # To simply show the date and time:
    # date
fi

# Install syslog-ng config
read -p "Do you want to restore the default syslog-ng configuration? [y,N] " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    if [ -f /etc/syslog-ng/syslog-ng.conf ]; then
        echo "Back up existing to /etc/syslog-ng/syslog-ng.conf.bak"
        mv /etc/syslog-ng/syslog-ng.conf /etc/syslog-ng/syslog-ng.conf.bak
    fi
    # We need a modifed version to makes this work!
    cp ./config/syslog-ng/syslog-ng.service /etc/systemd/system
    cp ./config/syslog-ng/syslog-ng.conf /etc/syslog-ng

    # Add logrotate config
    cp ./config/syslog-ng/syslog-ng.logrotate.conf /etc/logrotate.d/syslog-ng.conf

    # Cron jobs for logrotate
    LOGROTATE_CMD="/usr/sbin/logrotate /etc/logrotate.conf"
    LOGROTATE_SCHEDULE=" */15  *     * * *"
    add_cron_job "$LOGROTATE_CMD" "$LOGROTATE_SCHEDULE" true

    # TODO(swisstopo): If you want tu use remote logging, update syslog-ng configuration

    systemctl daemon-reload
    systemctl enable syslog-ng
    systemctl restart syslog-ng
fi

read -p "Do you want to restore the default e-mail (esmtp) configuration? [y,N] " -n 1 -r
echo # (optional) move to a new line
if [[ $REPLY =~ ^[Yy]$ ]]; then
    # Copy the config file to roots home
    cp ./config/.esmtprc ~/.esmtprc
    chmod 0710 ~/.esmtprc

    # Update identity
    email_identity="${hname}@swisstopo.ch"
    read -e -p "Email identity (hit ENTER to confirm): " -i "${email_identity}" -r email_identity
    echo # (optional) move to a new line
    add_or_replace_config_value ~/.esmtprc "identity" $email_identity true

    # Hints:
    # - Edit .esmtp as needed
    # - Define the test mail's body text: ioPeriodicPinCheck/body.txt - see below

    # To test:
    # Create a dummy mail file mail.txt:
    # <<
    # To: sdbrossi@gmail.com
    # Subject: sendmail test two
    # From: agni.ness@yandex.com
    #
    # And here goes the e-mail body, test test test..
    # >>
    #
    # Send it:
    # sendmail -v sdbrossi@gmail.com < mail.txt
fi

read -p "Do you want to set the default Watchdog configuration? [y,N] " -n 1 -r
echo # (optional) move to a new line
if [[ $REPLY =~ ^[Yy]$ ]]; then
    add_or_replace_config_value "/etc/systemd/system.conf" "RuntimeWatchdogSec" "22s" true
    add_or_replace_config_value "/etc/systemd/system.conf" "ShutdownWatchdogSec" "11min" true
    # See https://www.freedesktop.org/software/systemd/man/systemd-system.conf.html

    echo "To activate the watchdog configuration a reboot or re-executing"
    echo "systemd (systemctl daemon-reexec) is needed."
    read -p "Do you want to re-execute systemd ? [y,N] " -n 1 -r
    echo # (optional) move to a new line
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        systemctl daemon-reexec
    fi
fi

# Stop services that might disturb the installation process
echo "Stopping services"
# crond: runs pin testing
systemctl stop crond.service
# monkey: webserver
systemctl stop monkey.service
# iocontrolfcgi: fcgi application
systemctl stop iocontrolfcgi.socket iocontrolfcgi.service

# Install binaries
echo "Install ioControlFcgi"
cp ./ioControlFcgi /usr/bin/
# needed such that non-root users can access I2C stuff
chmod 4755 /usr/bin/ioControlFcgi

# Script for spawning fcgi application using systemd
cp ./systemd-spawn-fcgi.sh /usr/sbin/
chmod +x /usr/sbin/systemd-spawn-fcgi.sh

echo "Install ioControl"
cp ./ioControl /usr/bin/
# needed such that non-root users can access I2C stuff
chmod 4755 /usr/bin/ioControl

echo "Install periodic pin checking scripts"
cp -r ./ioPeriodicPinCheck /home/root
chmod +x /home/root/ioPeriodicPinCheck/*.sh

    email_from="${hname}@swisstopo.ch"
    read -e -p "Email sender for pin change notifications (hit ENTER to confirm): " -i "${email_from}" -r email_from
    echo # (optional) move to a new line
    add_or_replace_config_value /home/root/ioPeriodicPinCheck/emailreport.conf "from" $email_from true

#
# - Edit from/to/cc/bcc: ioPeriodicPinCheck/emailreport.conf
#   Hint: Maybe "from" should be used to indentify the station(?)
#         We could ask for a station name and used it in from and/or
#         add it to the body, subject and maybe alos to the webpage
#   Note: You can update this anytime using
#         scp my_emailreport.conf root@<IP_OR_HOSTNAME>:/home/root/ioPeriodicPinCheck/emailreport.conf
# - Currently the following pins are checked:
#   pin_list='IN1 IN2 CHARGER_FAIL POWER_FAIL BAT_FAIL OUT1'
#   If different pins are desired, edit ioPeriodicPinCheck/testpinchange.sh
#
# To test:
# ./emailreport.sh "TEST-SUBJECT" "ioPeriodicPinCheck/body.txt"

echo "Install webserver content"
WEB_ROOT_DIR="/var/www/monkey"

# Take .html.default, replace _ID_ by $hname_4c (see above) and save as .html
sed "/^ \{0,\}#/!s/_ID_/${hname_4c}/g" ./ioControlWeb/agnes_links.html.default > ./ioControlWeb/agnes_links.html

if [ -f "$WEB_ROOT_DIR/ioControlWeb/agnes_links.html" ]; then
    read -p "Keep the existing agnes_links.html? [y,N] " -n 1 -r
    echo # (optional) move to a new line
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        # rename the backup from above to use it (overwrite what we did above)
        cp "$WEB_ROOT_DIR/ioControlWeb/agnes_links.html" ./ioControlWeb/agnes_links.html
    fi
fi

echo "Copying (this takes a while) ..."
# Remove existing content and copy new whole www content
rm -rf  "$WEB_ROOT_DIR/ioControlWeb"
cp -rf ./ioControlWeb "$WEB_ROOT_DIR"

echo "Current content of agnes_links.html is:"
echo "<<"
cat "$WEB_ROOT_DIR/ioControlWeb/agnes_links.html"
echo
echo ">>"
echo
echo "You may edit it now using vi."
echo "(<i> insert/start writing, <ESC>:wq write&exit, <ESC>:q! discard&exit)"
read -p "Do you want to edit it now? [y,N] " -n 1 -r
echo # (optional) move to a new line
if [[ $REPLY =~ ^[Yy]$ ]]; then
    vi "$WEB_ROOT_DIR/ioControlWeb/agnes_links.html"
fi

# Configure fcgi
# https://redmine.lighttpd.net/projects/spawn-fcgi/wiki/Systemd,
# https://blog.tausys.de/2016/06/15/fastcgi-fuer-munin-mit-systemd/
cp ./config/iocontrolfcgi.service /etc/systemd/system/
cp ./config/iocontrolfcgi.socket /etc/systemd/system/

# Configure webserver
MONKEY_CONFIG_BACK_DIR="/home/root/monkey_config.bak"
echo "Moving current monkey config to $MONKEY_CONFIG_BACK_DIR (removing any existing backup)"
if [ -d "$MONKEY_CONFIG_BACK_DIR" ]; then
    rm -rf $MONKEY_CONFIG_BACK_DIR
fi
mv /etc/monkey $MONKEY_CONFIG_BACK_DIR
cp -r ./config/monkey /etc/

# Add user and password for webaccess (basic HTTP auth.)
# see mk_passwd --help
echo "Setting up web login using basic authentification..."

# if there was a user.mk, ask and get it back from the backup if requested.
WEB_ACCESS_USER_FILE="/etc/monkey/plugins/auth/users.mk"
WEB_ACCESS_USER_FILE_OLD="$MONKEY_CONFIG_BACK_DIR/plugins/auth/users.mk" 

if [ -f $WEB_ACCESS_USER_FILE_OLD ]; then
    read -p "users.mk already exists. Do you want to keep it? [y,N] " -n 1 -r
    echo # (optional) move to a new line
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        cp $WEB_ACCESS_USER_FILE_OLD $WEB_ACCESS_USER_FILE
    else
         # make sure we don't have a file
         # (in case it somehow went into the archive or stage)
        rm -f $WEB_ACCESS_USER_FILE
    fi
fi

if [ ! -f ${WEB_ACCESS_USER_FILE} ]; then
    WEB_USERNAME="webadmin"
    read -e -p "Web access username: " -i "$WEB_USERNAME" -r WEB_USERNAME
    echo # (optional) move to a new line
    while true; do
        read -s -p "Web access password: " WEB_PASSWD
        echo
        read -s -p "Web access password (again): " WEB_PASSWD2
        echo
        [ "$WEB_PASSWD" = "$WEB_PASSWD2" ] && break
        echo "Please try again"
    done   
    mk_passwd -c $WEB_ACCESS_USER_FILE $WEB_USERNAME $WEB_PASSWD
    echo "Registered user ${WEB_USERNAME} for web acces via basic authentification."
fi

# Setup service for webserver (start it later)
cp ./config/monkey/monkey.service /etc/systemd/system/

# Cron jobs for for checking pins and sending emails
REPORTPIN_CMD="cd /home/root/ioPeriodicPinCheck/ && ./reportpinchange.sh 2>&1 | /usr/bin/logger -t PINCHANGE"
TESTPIN_INIT_CMD="cd /home/root/ioPeriodicPinCheck/ && ./testpinchange.sh --clear"
REPORTPIN_SCHEDULE=" */2  *     * * *"
TESTPIN_INIT_SCHEDULE="@reboot        "

add_cron_job "$REPORTPIN_CMD" "$REPORTPIN_SCHEDULE" true
add_cron_job "$TESTPIN_INIT_CMD" "$TESTPIN_INIT_SCHEDULE" true

# Reset state
/home/root/ioPeriodicPinCheck/testpinchange.sh --clear
# Next time cron runs REPORTPIN_CMD, it should send an email.

# Re-/start services
echo "Starting services"
systemctl daemon-reload
# crond: runs pin testing
systemctl enable crond.service
systemctl start crond.service
# iocontrolfcgi: fcgi application
systemctl enable iocontrolfcgi.socket iocontrolfcgi.service
systemctl start iocontrolfcgi.socket iocontrolfcgi.service
# monkey: webserver
systemctl enable monkey.service
systemctl start monkey.service

# -- if change and requested, restart networking
if [[ $NETWORK_CONFIG_CHANGED == true ]]; then
    echo "The network config might have been changed."
    echo "To apply the changes the service needs to be restarted, which"
    echo "may disconnect you."
    echo "Instead you can later restart the service using:"
    echo "  systemctl restart systemd-networkd"
    echo "or reboot the device using:"
    echo "  reboot"
    echo "If the change affect an interface you are not connected to,"
    echo "you can try"
    echo "  ip link set dev eth0 down"
    echo "  ip link set dev eth0 up"
    echo "or"
    echo "  ip link set dev eth1 down"
    echo "  ip link set dev eth1 up"
    read -p "Do you want to restart the network service now? [y,N] " -n 1 -r
    echo # (optional) move to a new line
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        systemctl restart systemd-networkd
    fi
fi

chmod +x cleanup_install.sh
echo "Installation complete"
echo 
echo "To clean up you can use:"
echo "cd .. && ./stage/cleanup_install.sh"
echo
